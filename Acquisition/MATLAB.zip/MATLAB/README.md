Info on DAQsoftware for the MATLAB.

Written for MATLAB R2016b.

