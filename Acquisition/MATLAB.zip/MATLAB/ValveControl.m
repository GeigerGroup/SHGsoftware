classdef ValveControl
    %object to control valves
    
    properties
        LabJack
    end
    
    methods
        function obj = ValveControl()

        end
        
    end
end

